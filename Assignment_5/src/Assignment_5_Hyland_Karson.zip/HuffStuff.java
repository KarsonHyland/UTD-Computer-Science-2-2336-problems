
public class HuffStuff {
	
	protected String codes;
	protected String Letters;
	
	public HuffStuff(String code, String letter) {
		this.codes = code;
		this.Letters = letter;
	}
	
	public String getCode() {
		return codes;
	}
	
	public String getLetter() {
		return Letters;
	}
}
